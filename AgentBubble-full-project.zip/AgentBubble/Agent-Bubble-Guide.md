# Agent Bubble — 3.0.0-rc5

Install: `AgentBubble-v3.0.0-rc5.apk` (~35 MiB), versionCode 26.
Android 13+ (min SDK 33), arm64-v8a devices only. Same package and signing certificate as v2.1.3, so install as an update, not by uninstalling. Existing settings and chats are retained by the update; API keys are migrated to device-bound encrypted storage. Uninstalling clears app data.

## Status and verification

This is an installable release candidate, not a claim of completed production/device certification.

- Release assembly: passed.
- 71 automated tests: 47 existing service/UI/chat regressions + 24 operator/security/tool-calling tests, 0 failures/errors.
- Android lint: 0 errors, 115 warnings remain (including compatibility, localization, accessibility and dependency-update warnings).
- APK signature: verified; certificate matches v2.1.3.
- Tested with Robolectric and mock API responses, NOT a physical Samsung device or real downloaded local model.
- Native CPU inference, RAM usage, One UI keyboard behavior, gesture completion and third-party app behavior need on-device acceptance tests.

## Install and API chat

1. Download and install the APK over the existing version. Do not uninstall first.
2. Open Agent Bubble. Grant display-over-other-apps permission and allow notifications.
3. Choose model: enter your OpenAI-compatible provider base URL and API key, fetch the provider's live model list, search and select a model. OpenRouter remains the default base URL.
4. Open `API / Local model · Action setup` and select **Use API model**.
5. Show the bubble. Tap it to open the floating card. Default mode is **Chat · no actions**.
6. Type and send. Chat does not inspect your screen or use accessibility.

The card keeps its remembered position and size. The selected Chat/Automation mode now survives closing the action controller and reopening the chat. Drag its title bar to move it; drag left/top edges to resize. History is inside the card under the clock icon, grouped by provider/model. Enter sends; close returns to the bubble. Hold the bubble for two seconds to stop the service.

## Offline model

1. Obtain a trusted, compatible LiteRT-LM `.litertlm` model separately. The APK includes the runtime, NOT model weights. GGUF/Ollama models cannot be imported directly.
2. Open AI setup → **Import .litertlm model**. Keep this screen open during import. The app copies and hashes the file, then attempts CPU runtime initialization before committing the new model. Failed/cancelled imports keep the previous selection.
3. Choose **Use imported Local model**.
4. Return to the bubble and use Chat or Action mode.

No automatic cloud fallback occurs. Source choice applies to both chat and actions. Local-model history is separated by model content hash. Only one model is installed in the slot at a time; old chat records are retained.

Models are limited to 4 GiB by import code, but that is NOT a recommendation: available RAM may be much lower. Large models may be slow or terminate the app under memory pressure. Native inference is serialized and initialized per generation. Cancelling a request prevents its response from causing actions, but native computation may continue until the runtime returns. No local-model/device combination was verified here.

## Phone actions

1. Read the disclosure in AI setup. Accessibility is optional for Chat and required only for Action tasks.
2. Tap **I understand · open Accessibility settings**, confirm, then enable Agent Bubble in Android accessibility settings.
3. For a sideload restriction, Android may require Settings → Apps → Agent Bubble → menu → Allow restricted settings. The option depends on the device/OS.
4. Open the target app, then open the bubble. Change **Chat · no actions** to **Action · approve steps**.
5. Write the task and send. The chat closes and a compact draggable Action controller appears.
6. Read each proposed step, including arguments and target app. **Allow once** approves that one proposal. **Stop** denies pending approval and cancels the run.
7. On completion, use **Back to chat**. The result is saved in the originating chat.

Supported action tools: inspect accessible UI text, open an app, click exact text/node, type into an editable node, scroll, safe coordinate tap fallback, swipe, Back, Home and bounded waits. Every mutating step needs approval. Duplicate app/text matches are rejected rather than choosing arbitrarily. A changed screen invalidates pending approval. Shell, arbitrary intents, password entry and destructive file tools are deliberately not exposed. `inspect_visual` is available only in explicit Automation mode; local vision requires a compatible local vision model.

For API AI in Automation mode, the provider receives an OpenAI-compatible `tools` schema and the model returns function/tool calls. Tool results are returned to the model for the next planning turn. For Local AI, the same allow-list and safety loop is used through the local model's structured JSON tool protocol; local model compatibility varies, so the model must follow the listed arguments. The runner is bounded to 40 steps / 10 minutes, stops repeated no-progress proposals, and never automatically resumes after process death. The model's final summary is labelled as such; verify outcomes in the target app.

## Privacy and safety

- API Action mode sends accessible screen text to the selected provider. Review that provider's privacy policy. Local Action mode performs inference on-device.
- Chat sends only its conversation, not the current phone screen.
- Detected password/authentication screens are blocked before screen text is sent. Heuristic detection is not a universal secret detector; do not run tasks in banking, password managers or authentication flows.
- Normal Chat never captures screenshots. Explicit API Automation may call `inspect_visual` when accessibility cannot expose a visible control; the screenshot is sent to the selected vision-capable provider and is not stored by Agent Bubble. Secure/protected flows are blocked before upload and are not bypassed.
- Every phone-changing step requires explicit approval, including send/delete-type controls. There is no global sensitive-action bypass toggle.
- Stop prevents further proposed actions; an already-dispatched Android gesture may finish.
- Provider keys use Android Keystore-backed AES-GCM encryption, bound to the provider ID. Backups/device transfer are excluded. Chat history remains local app-private storage, not separately encrypted.
- Do not approve unrelated steps prompted by web pages or messages. Screen content can contain malicious instructions; safeguards do not make arbitrary automation risk-free.

## On-device acceptance checklist

- Update preserves existing provider settings and saved chats.
- Bubble open → caret/keyboard ready; send → next message can be typed without tapping again.
- Float/resize/history work while keyboard is open.
- API chat replies using the selected provider/model.
- Local import validates a compatible small model, then Chat works with network disconnected.
- A simple Action task (open Calculator) requests approval and runs only after approval.
- Stop during planning/approval prevents later actions; changing the screen invalidates approval.
- Disabling accessibility during a task stops the next inspection/action cycle.
- No app automation occurs in Chat mode.

## Build provenance

Adapted bounded node traversal, controller ideas and Keystore security from the user's `hemantbhatt63883428-star/local-phone-operator` repository, main commit `0bc6c36cd67e773e918580d8fb53f739f8fff12d`; reconstructed source archive checksum verified before review. The original global-risk toggle, old overlay and unapproved automation loop were not imported.

Build: JDK 21, Gradle 8.14.4, AGP 8.7.3, Kotlin 2.4.0, compile SDK 35, target SDK 34, LiteRT-LM 0.17.1. Run `:app:testDebugUnitTest :app:lintDebug :app:assembleRelease`. Logs in `.buildlogs/v3-tools-delivery.log`; APK checksum in `AgentBubble-v3.0.0-rc5.sha256`.
