plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.agentbubble"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.agentbubble"
        minSdk = 33
        targetSdk = 34
        versionCode = 26
        versionName = "3.0.0-rc5"
        resourceConfigurations += listOf("en")
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    val localKeystore = file("keystore.jks")
    signingConfigs {
        if (localKeystore.exists()) {
            create("selfsign") {
                storeFile = localKeystore
                storePassword = "agentbubble"
                keyAlias = "agentbubble"
                keyPassword = "agentbubble"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            if (localKeystore.exists()) signingConfig = signingConfigs.getByName("selfsign")
        }
        debug {
            if (localKeystore.exists()) signingConfig = signingConfigs.getByName("selfsign")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures {
        viewBinding = true
    }

    testOptions {
        unitTests {
            isIncludeAndroidResources = true
            isReturnDefaultValues = true
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    // On-device OCR: lets a text-only model read words that live inside pictures/canvas/video.
    // Unbundled: the model comes from Play services on first use, so the APK stays small.
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.17.1")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.14.1")
    testImplementation("androidx.test:core:1.6.1")
    testImplementation("androidx.test.ext:junit:1.2.1")
    testImplementation("com.squareup.okhttp3:mockwebserver:4.12.0")
}

kotlin { compilerOptions { jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17) } }
