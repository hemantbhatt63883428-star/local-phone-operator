package com.agentbubble.operator

import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.agentbubble.data.SettingsStore
import com.agentbubble.service.BubbleService
import kotlinx.coroutines.*

class RuntimeActivity : AppCompatActivity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var status: TextView
    private lateinit var store: SettingsStore
    private var importing = false
    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && !importing) scope.launch {
            importing = true
            status.text = "Importing and validating on CPU… Keep this screen open. Large models need free RAM and storage."
            try {
                val id = LocalModels.import(this@RuntimeActivity, uri)
                status.text = "Imported $id. Select Local below to use it."
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { status.text = "Import failed; previous model kept. ${e.message}" }
            catch (e: LinkageError) { status.text = "Local runtime not compatible with this device: ${e.message}" }
            finally { importing = false }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SettingsStore(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 30, 28, 30) }
        setContentView(ScrollView(this).apply { addView(col) })
        fun text(s: String) = TextView(this).apply { text = s; textSize = 16f; setPadding(0, 14, 0, 14); col.addView(this) }
        fun button(s: String, action: () -> Unit) { col.addView(Button(this).apply { text = s; setOnClickListener { action() } }) }
        text("AI source & phone actions").textSize = 24f
        status = text("")
        updateStatus()
        text("API: uses your existing provider + searchable model list. Local: offline inference on this phone, no API key. A compatible .litertlm model must be imported separately; GGUF files are not supported. No silent cloud fallback.")
        button("Use API model") { store.useLocal = false; refreshSource() }
        button("Import .litertlm model") { if (!importing) picker.launch(arrayOf("*/*")) }
        button("Use imported Local model") {
            if (LocalModels.config(this).model.isBlank()) status.text = "Import a compatible model first."
            else { store.useLocal = true; refreshSource() }
        }
        text("Action privacy & control\nChat mode never reads the screen or controls apps. Action mode reads accessible screen text while your task runs. With API selected, that text is sent to your selected provider. With Local selected, inference stays on-device. No screenshots are captured in this release.\n\nEach phone-changing step requires Allow once. Stop cancels pending approvals and blocks further actions. Authentication/password screens are blocked. Never approve a step you do not recognize.")
        button("I understand · open Accessibility settings") {
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Enable phone actions?")
                .setMessage("Accessibility lets Agent Bubble read app text and perform gestures. Only Action tasks use this access. API Action tasks send screen text to your configured provider. You can disable this access in Android settings at any time.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Open settings") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }.show()
        }
        text("Android may block accessibility for sideloaded apps: Settings → Apps → Agent Bubble → ⋮ → Allow restricted settings, then return here. Do not enable access unless you trust this APK.\n\nRuns stop at 40 steps or 10 minutes; no background auto-resume. Your model must follow structured JSON instructions. Some apps hide controls from accessibility; those tasks may not work.")
        button("Back to Bubble settings") { finish() }
    }
    private fun refreshSource() { updateStatus(); BubbleService.send(this, BubbleService.ACTION_REFRESH) }
    private fun updateStatus() {
        status.text = "Selected: " + (if (store.useLocal) "Local" else "API") + "\nModel: " + (store.activeProvider()?.model?.ifBlank { "not selected" } ?: "not selected")
    }
    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
