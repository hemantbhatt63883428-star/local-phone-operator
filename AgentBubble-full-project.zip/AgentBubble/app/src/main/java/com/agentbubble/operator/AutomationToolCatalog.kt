package com.agentbubble.operator

import com.google.ai.edge.litertlm.Tool
import com.google.ai.edge.litertlm.ToolParam
import com.google.ai.edge.litertlm.ToolSet
import org.json.JSONArray
import org.json.JSONObject

/**
 * The safe automation surface shared by API function-calling and the local LiteRT planner.
 *
 * This is intentionally narrower than a general remote-control API: there is no shell, file
 * deletion, arbitrary intent, password entry, or silent coordinate click. Mutations are still
 * approved by ActionPanel before ActionRunner dispatches them.
 */
object AutomationToolCatalog {
    val names = setOf(
        "inspect_screen", "open_app", "click_text", "click_node", "type_text", "scroll",
        "tap", "swipe", "back", "home", "wait_ms", "finish"
    )

    fun isMutation(name: String): Boolean = name !in setOf("inspect_screen", "wait_ms", "finish")

    fun apiSchema(): JSONArray = JSONArray().apply {
        put(tool("inspect_screen", "Inspect the current Android accessibility UI tree before acting and after navigation.",
            obj("max_nodes", "integer", "Maximum nodes, normally 60 to 120"), listOf("max_nodes")))
        put(tool("open_app", "Open an installed Android app by exact visible label or package name.",
            obj("name", "string", "App label or package"), listOf("name")))
        put(tool("click_text", "Click visible text or accessibility label. Prefer this over coordinates.", properties(
            "text" to spec("string", "Visible text or accessibility label"),
            "exact" to spec("boolean", "Require an exact match")
        ), listOf("text", "exact")))
        put(tool("click_node", "Click a UI node from the latest inspect_screen result.",
            obj("node_id", "integer", "Node id"), listOf("node_id")))
        put(tool("type_text", "Enter text into an editable node. Password and PIN fields are blocked.", properties(
            "text" to spec("string", "Text to enter"),
            "node_id" to spec("integer", "Editable node id, or -1 for focused editable field"),
            "append" to spec("boolean", "Append instead of replacing")
        ), listOf("text", "node_id", "append")))
        put(tool("scroll", "Scroll the current page.", enumObj("direction", listOf("down", "up", "left", "right"), "Direction"), listOf("direction")))
        put(tool("tap", "Tap an accessible screen location only when text/node controls cannot represent it. Sensitive targets are blocked.", properties(
            "x" to spec("integer", "X screen pixel"), "y" to spec("integer", "Y screen pixel")
        ), listOf("x", "y")))
        put(tool("swipe", "Swipe the screen to reveal or move through content. Avoid sensitive controls.", properties(
            "x1" to spec("integer", "Start X"), "y1" to spec("integer", "Start Y"),
            "x2" to spec("integer", "End X"), "y2" to spec("integer", "End Y"),
            "duration_ms" to spec("integer", "100 to 1800 milliseconds")
        ), listOf("x1", "y1", "x2", "y2", "duration_ms")))
        put(tool("back", "Press Android Back.", JSONObject(), emptyList()))
        put(tool("home", "Press Android Home. This may leave the task app.", JSONObject(), emptyList()))
        put(tool("wait_ms", "Wait briefly for a screen transition.", obj("milliseconds", "integer", "50 to 3000"), listOf("milliseconds")))
        put(tool("finish", "Finish only after verifying the requested result, or state the limitation.",
            obj("summary", "string", "What happened and what remains"), listOf("summary")))
    }

    private fun tool(name: String, description: String, props: JSONObject, required: List<String>): JSONObject {
        val params = JSONObject().put("type", "object").put("properties", props).put("additionalProperties", false)
        if (required.isNotEmpty()) params.put("required", JSONArray(required))
        return JSONObject().put("type", "function").put("function", JSONObject()
            .put("name", name).put("description", description).put("parameters", params))
    }
    private fun obj(name: String, type: String, description: String) = properties(name to spec(type, description))
    private fun enumObj(name: String, values: List<String>, description: String) =
        properties(name to spec("string", description).put("enum", JSONArray(values)))
    private fun properties(vararg pairs: Pair<String, JSONObject>) = JSONObject().apply { pairs.forEach { put(it.first, it.second) } }
    private fun spec(type: String, description: String) = JSONObject().put("type", type).put("description", description)
}

/** LiteRT-LM's local tool schema. Tool execution remains in ActionRunner after approval. */
class AndroidAutomationToolSet : ToolSet {
    @Tool(description = "Inspect the current Android accessibility UI tree before and after actions.")
    fun inspect_screen(@ToolParam(description = "Maximum nodes, normally 60 to 120.") max_nodes: Int): String = "schema"
    @Tool(description = "Open an installed app by visible label or package name.")
    fun open_app(@ToolParam(description = "App label or package.") name: String): String = "schema"
    @Tool(description = "Click visible text or accessibility label; prefer over coordinates.")
    fun click_text(@ToolParam(description = "Visible label.") text: String, @ToolParam(description = "Exact match.") exact: Boolean): String = "schema"
    @Tool(description = "Click a node from the latest inspect_screen result.")
    fun click_node(@ToolParam(description = "Node id.") node_id: Int): String = "schema"
    @Tool(description = "Type non-secret text into an editable node.")
    fun type_text(@ToolParam(description = "Text.") text: String, @ToolParam(description = "Node id or -1.") node_id: Int, @ToolParam(description = "Append instead of replace.") append: Boolean): String = "schema"
    @Tool(description = "Scroll the current page.")
    fun scroll(@ToolParam(description = "down, up, left or right.") direction: String): String = "schema"
    @Tool(description = "Tap an accessible coordinate fallback; sensitive targets are blocked.")
    fun tap(@ToolParam(description = "X pixels.") x: Int, @ToolParam(description = "Y pixels.") y: Int): String = "schema"
    @Tool(description = "Swipe to reveal content.")
    fun swipe(@ToolParam(description = "Start X.") x1: Int, @ToolParam(description = "Start Y.") y1: Int, @ToolParam(description = "End X.") x2: Int, @ToolParam(description = "End Y.") y2: Int, @ToolParam(description = "Duration.") duration_ms: Int): String = "schema"
    @Tool(description = "Press Android Back.")
    fun back(): String = "schema"
    @Tool(description = "Press Android Home.")
    fun home(): String = "schema"
    @Tool(description = "Wait for a transition.")
    fun wait_ms(@ToolParam(description = "50 to 3000 milliseconds.") milliseconds: Int): String = "schema"
    @Tool(description = "Finish after verifying the task.")
    fun finish(@ToolParam(description = "Summary and limitations.") summary: String): String = "schema"
}
