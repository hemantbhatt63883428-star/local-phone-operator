package com.agentbubble.operator

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

/** Passive unless a user explicitly starts an Action task. No overlay or polling on connect. */
class OperatorAccessibilityService : AccessibilityService() {
    companion object { @Volatile var connected: OperatorAccessibilityService? = null; private set }
    override fun onServiceConnected() { connected = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() { if (connected === this) connected = null }
    override fun onDestroy() { if (connected === this) connected = null; super.onDestroy() }

    /**
     * Return the focused external application, never Agent Bubble's own overlay. During an IME or
     * overlay transition rootInActiveWindow/windows can briefly be empty; ActionRunner retries before
     * declaring failure instead of asking the user to reopen an already-visible app.
     */
    fun targetRoot(): AccessibilityNodeInfo? {
        val own = packageName
        val active = runCatching { rootInActiveWindow }
            .getOrNull()
            ?.takeIf { it.packageName?.toString() != own }
        if (active != null) return active
        val apps = runCatching { windows.toList() }.getOrDefault(emptyList())
            .filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
            .sortedWith(compareByDescending<AccessibilityWindowInfo> { it.isFocused }
                .thenByDescending { it.isActive }
                .thenByDescending { it.layer })
        return apps.asSequence()
            .mapNotNull { runCatching { it.root }.getOrNull() }
            .firstOrNull { it.packageName?.toString() != own }
    }
}
