package com.agentbubble.operator

import android.content.Context
import android.net.Uri
import com.agentbubble.data.ChatMessage
import com.agentbubble.data.ProviderConfig
import com.google.ai.edge.litertlm.*
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.security.MessageDigest

/** Serialized native inference. No network fallback, and no tools in chat. */
object LocalModels {
    private val lock = Mutex()
    private fun prefs(c: Context) = c.getSharedPreferences("local_model", Context.MODE_PRIVATE)
    fun config(c: Context): ProviderConfig = ProviderConfig("local-litert", "Offline · LiteRT-LM", "local://litert", "",
        prefs(c).getString("modelId", "").orEmpty())
    fun path(c: Context): String = prefs(c).getString("path", "").orEmpty()
    suspend fun import(c: Context, uri: Uri): String = withContext(Dispatchers.IO) {
        lock.withLock {
            val dir = File(c.filesDir, "models").apply { mkdirs() }
            val temp = File.createTempFile("import-", ".tmp", dir)
            try {
                val hash = MessageDigest.getInstance("SHA-256")
                var total = 0L
                c.contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Cannot read selected model" }
                    temp.outputStream().buffered().use { output ->
                        val buf = ByteArray(1024 * 1024)
                        while (true) {
                            currentCoroutineContext().ensureActive()
                            val n = input.read(buf); if (n < 0) break
                            total += n
                            require(total <= 4L * 1024 * 1024 * 1024) { "Model exceeds 4 GB limit" }
                            require(dir.usableSpace > n + 64L * 1024 * 1024) { "Not enough free storage" }
                            hash.update(buf, 0, n); output.write(buf, 0, n)
                        }
                    }
                }
                require(total > 1024) { "Model file is empty or invalid" }
                // Validate with the actual runtime before replacing the previous model.
                Engine(EngineConfig(modelPath = temp.absolutePath, backend = Backend.CPU(),
                    cacheDir = c.cacheDir.absolutePath)).use { it.initialize() }
                currentCoroutineContext().ensureActive()
                val id = "litert-" + hash.digest().joinToString("") { "%02x".format(it) }.take(16)
                val target = File(dir, "$id.litertlm")
                if (!target.exists()) check(temp.renameTo(target)) { "Could not commit model" }
                val old = path(c)
                check(prefs(c).edit().putString("path", target.absolutePath).putString("modelId", id).commit())
                if (old.isNotBlank() && old != target.absolutePath) File(old).delete()
                id
            } finally { temp.delete() }
        }
    }
    suspend fun generate(c: Context, cfg: ProviderConfig, history: List<ChatMessage>): String = withContext(Dispatchers.IO) {
        lock.withLock {
            require(cfg.model.isNotBlank() && cfg.model == config(c).model) { "Local model changed; reopen chat" }
            val file = File(path(c)); require(file.isFile) { "Import a compatible .litertlm model in AI setup" }
            currentCoroutineContext().ensureActive()
            Engine(EngineConfig(modelPath = file.absolutePath, backend = Backend.CPU(), cacheDir = c.cacheDir.absolutePath)).use { engine ->
                engine.initialize()
                currentCoroutineContext().ensureActive()
                val system = history.firstOrNull { it.role == "system" }?.content ?: "You are a helpful assistant."
                engine.createConversation(ConversationConfig(systemInstruction = Contents.of(system), maxOutputToken = 1024)).use { conv ->
                    // Bounded transcript works with models which do not expose tool/function calling.
                    val transcript = history.filter { it.role != "system" }.takeLast(16)
                        .joinToString("\n\n") { "${it.role.uppercase()}: ${it.content.take(10000)}" }.takeLast(24000)
                    val response = conv.sendMessage(Message.user(transcript)).toString()
                    currentCoroutineContext().ensureActive() // cancelled native responses never cause actions
                    response
                }
            }
        }
    }
}
