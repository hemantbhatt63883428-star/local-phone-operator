package com.agentbubble.operator

import android.content.Context

/** All mutations already require approval; authentication is still hard-blocked. */
object SafetyPolicy {
    private val protected = Regex("password|passcode|\\bpin\\b|\\botp\\b|one.time.code|verification.code|recovery.code|captcha|biometric|fingerprint|authenticator", RegexOption.IGNORE_CASE)
    fun protectedText(text: String): Boolean = protected.containsMatchIn(text)
    fun mayClick(context: Context, label: String?): Pair<Boolean, String> =
        (!protectedText(label.orEmpty())) to "Authentication controls require manual interaction"
    fun mayTypeInto(isPassword: Boolean): Pair<Boolean, String> = (!isPassword) to "Password fields cannot be automated"
}
