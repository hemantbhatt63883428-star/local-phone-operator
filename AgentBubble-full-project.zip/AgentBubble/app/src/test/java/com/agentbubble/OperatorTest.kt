package com.agentbubble

import android.content.Context
import android.widget.Button
import androidx.test.core.app.ApplicationProvider
import com.agentbubble.data.*
import com.agentbubble.operator.*
import com.agentbubble.net.LlmClient
import com.agentbubble.service.BubbleService
import kotlinx.coroutines.*
import okhttp3.mockwebserver.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.json.JSONObject
import java.util.concurrent.TimeUnit

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class OperatorTest {
    private val ctx: Context get() = ApplicationProvider.getApplicationContext()
    private val cfg = ProviderConfig("mock", "Mock", "https://example.test/v1", "key", "model")
    @Before fun setup() {
        val key = javax.crypto.KeyGenerator.getInstance("AES").apply { init(256) }.generateKey()
        SecretVault.keyProvider = { key }
    }
    private class FakeDevice : ActionDevice {
        var screen = "ACTIVE_PACKAGE=test\n#0 t=button"
        var mutations = 0
        override suspend fun observe() = screen
        override suspend fun execute(proposal: Proposal): String { if (proposal.mutates) mutations++; return "OK" }
    }
    @Test fun protocolRejectsUnknownTools() {
        assertThrows(IllegalArgumentException::class.java) { Proposal.parse("""{"tool":"shell","args":{"cmd":"rm"}}""") }
    }
    @Test fun proseIsNotExecutable() {
        assertThrows(IllegalArgumentException::class.java) { Proposal.parse("I clicked the button") }
    }
    @Test fun coordinateFallbackIsAllowListedAndStillNeedsApproval() {
        val p = Proposal.parse("""{"tool":"tap","args":{"x":1,"y":2}}""")
        assertTrue(p.mutates)
        assertTrue(Proposal.parse("""{"tool":"swipe","args":{"x1":1,"y1":2,"x2":3,"y2":4,"duration_ms":300}}""").mutates)
    }
    @Test fun allMutatingToolsNeedApproval() {
        Proposal.allowed.forEach { tool ->
            val p = Proposal.parse("""{"tool":"$tool"}""")
            assertEquals(tool !in setOf("finish", "wait_ms", "inspect_screen"), p.mutates)
        }
    }
    @Test fun deniedProposalNeverExecutes() = runBlocking {
        val d = FakeDevice()
        val runner = ActionRunner(ctx, d, { """{"tool":"home"}""" }, 0)
        val result = runner.run("home", cfg, {}) { false }
        assertEquals(0, d.mutations); assertTrue(result.contains("not approved"))
    }
    @Test fun approvedStepExecutesExactlyOnce() = runBlocking {
        val d = FakeDevice(); var n = 0; var approvals = 0
        val runner = ActionRunner(ctx, d, { if (n++ == 0) """{"tool":"home"}""" else """{"tool":"finish","args":{"summary":"done"}}""" }, 0)
        val result = runner.run("home", cfg, {}) { approvals++; true }
        assertEquals(1, d.mutations); assertEquals(1, approvals); assertTrue(result.contains("Model's summary"))
    }
    @Test fun changedScreenInvalidatesApproval() = runBlocking {
        val d = FakeDevice(); var n = 0
        val runner = ActionRunner(ctx, d, { if (n++ == 0) """{"tool":"click_node","args":{"node_id":0}}""" else """{"tool":"finish","args":{"summary":"changed"}}""" }, 0)
        runner.run("click", cfg, {}) { d.screen = "different app"; true }
        assertEquals(0, d.mutations)
    }
    @Test fun cancelWhileAwaitingApprovalPreventsAction() = runBlocking {
        val d = FakeDevice(); val waiting = CompletableDeferred<Unit>()
        val runner = ActionRunner(ctx, d, { """{"tool":"home"}""" }, 0)
        val job = launch { runner.run("home", cfg, {}) { waiting.complete(Unit); awaitCancellation() } }
        waiting.await(); job.cancelAndJoin(); assertEquals(0, d.mutations)
    }
    @Test fun cancelBeforeLateModelResponsePreventsAction() = runBlocking {
        val d = FakeDevice(); val started = CompletableDeferred<Unit>()
        val runner = ActionRunner(ctx, d, {
            started.complete(Unit)
            try { awaitCancellation() } catch (_: CancellationException) { """{"tool":"home"}""" }
        }, 0)
        var approved = false
        val job = launch { runner.run("home", cfg, {}) { approved = true; true } }
        started.await(); job.cancelAndJoin(); assertEquals(0, d.mutations); assertFalse(approved)
    }
    @Test fun repeatedNoProgressStopsRun() = runBlocking {
        val d = FakeDevice()
        val runner = ActionRunner(ctx, d, { """{"tool":"home"}""" }, 0)
        try { runner.run("home", cfg, {}) { true }; fail("Must stop") }
        catch (e: IllegalStateException) { assertTrue(e.message!!.contains("No progress")) }
        assertEquals(3, d.mutations)
    }
    @Test fun budgetIsBoundedEvenWhenScreenChanges() = runBlocking {
        val d = FakeDevice(); var step = 0
        val runner = ActionRunner(ctx, d, { """{"tool":"home"}""" }, 0)
        val result = runner.run("home", cfg, { if (it.startsWith("Planning")) d.screen = "screen ${step++}" }) { true }
        assertTrue(result.contains("40-step")); assertTrue(d.mutations <= 40)
    }
    @Test fun protectedFieldsAreHardBlocked() {
        listOf("Password", "PIN", "Enter OTP", "verification code", "CAPTCHA", "fingerprint").forEach { assertTrue(it, SafetyPolicy.protectedText(it)) }
        assertFalse(SafetyPolicy.mayTypeInto(true).first)
        assertTrue(SafetyPolicy.mayTypeInto(false).first)
    }
    @Test fun apiKeysAreEncryptedAndMigrated() {
        val sp = ctx.getSharedPreferences("agentbubble", Context.MODE_PRIVATE)
        sp.edit().putString("providers", """[{"id":"one","model":"m","apiKey":"old-secret"}]""").commit()
        val store = SettingsStore(ctx)
        assertEquals("old-secret", store.providers()[0].apiKey)
        val disk = sp.getString("providers", "")!!
        assertFalse(disk.contains("old-secret")); assertTrue(disk.contains("apiKeyCipher"))
        assertEquals("old-secret", store.providers()[0].apiKey)
    }
    @Test fun providerBindingRejectsCiphertextSwap() {
        val encrypted = SecretVault.encrypt("one", "secret")
        assertEquals("secret", SecretVault.decrypt("one", encrypted))
        assertThrows(Exception::class.java) { SecretVault.decrypt("two", encrypted) }
    }
    @Test fun localSelectionDoesNotDestroyApiConfig() {
        val store = SettingsStore(ctx); store.upsertProvider(cfg)
        store.useLocal = true
        assertEquals("local://litert", store.activeProvider()!!.baseUrl)
        store.useLocal = false
        assertEquals("key", store.activeProvider()!!.apiKey)
    }
    @Test fun runtimeSettingsActivityInflates() {
        val activity = Robolectric.buildActivity(RuntimeActivity::class.java).setup()
        assertNotNull(activity.get().findViewById<android.view.View>(android.R.id.content))
        activity.pause().stop().destroy()
    }
    @Test fun chatDefaultsToNoActionsAndCanSwitchExplicitly() {
        val service = Robolectric.buildService(BubbleService::class.java).create()
        service.get().openChat()
        val root = service.get().panelRootForTest()!!
        val chat = root.findViewById<Button>(R.id.btnChatMode)
        val automation = root.findViewById<Button>(R.id.btnAutomationMode)
        assertEquals("✓ Chat", chat.text.toString()); assertEquals("Automation", automation.text.toString())
        automation.performClick(); assertEquals("Chat", chat.text.toString()); assertEquals("✓ Automation", automation.text.toString())
        chat.performClick(); assertEquals("✓ Chat", chat.text.toString()); assertEquals("Automation", automation.text.toString())
        root.findViewById<Button>(R.id.btnLocalSource).performClick()
        assertTrue(SettingsStore(ctx).useLocal)
        root.findViewById<Button>(R.id.btnApiSource).performClick()
        assertFalse(SettingsStore(ctx).useLocal)
        service.get().closeChat(); service.destroy()
    }
    @Test fun explicitAutomationModePersistsAcrossChatReopen() {
        val store = SettingsStore(ctx)
        store.automationMode = true
        assertTrue(SettingsStore(ctx).automationMode)
        store.automationMode = false
        assertFalse(SettingsStore(ctx).automationMode)
    }
    @Test fun chatDoesNotRequireAccessibility() {
        assertNull(OperatorAccessibilityService.connected)
        val service = Robolectric.buildService(BubbleService::class.java).create()
        service.get().openChat(); assertNotNull(service.get().panelRootForTest())
        service.get().closeChat(); service.destroy()
    }
    @Test fun httpCancellationDoesNotWaitForServerTimeout() = runBlocking {
        val server = MockWebServer()
        server.enqueue(MockResponse().setSocketPolicy(SocketPolicy.NO_RESPONSE)); server.start()
        val config = cfg.copy(baseUrl = server.url("/v1").toString())
        val job = launch(Dispatchers.IO) { LlmClient(config).chat(listOf(ChatMessage("user", "test"))) }
        assertNotNull(withContext(Dispatchers.IO) { server.takeRequest(5, TimeUnit.SECONDS) })
        withTimeout(2000) { job.cancelAndJoin() }
        server.shutdown()
    }
    @Test fun apiActionUsesCurrentProviderAndJsonProtocol() = runBlocking {
        val server = MockWebServer(); server.start()
        server.enqueue(MockResponse().setBody("""{"choices":[{"message":{"tool_calls":[{"id":"call_finish","type":"function","function":{"name":"finish","arguments":"{\"summary\":\"No action needed\"}"}}]}}]}"""))
        val d = FakeDevice()
        val config = cfg.copy(baseUrl = server.url("/v1").toString())
        val result = ActionRunner(ctx, d, settleMs = 0).run("check", config, {}) { fail("No approval needed"); false }
        val req = server.takeRequest()
        assertEquals("Bearer key", req.getHeader("Authorization"))
        val json = JSONObject(req.body.readUtf8())
        assertEquals("model", json.getString("model")); assertTrue(json.has("tools"))
        assertEquals("auto", json.getString("tool_choice"))
        assertTrue(json.toString().contains("inspect_visual") == false)
        assertTrue(json.toString().contains("UNTRUSTED CURRENT SCREEN"))
        assertTrue(result.contains("No action needed")); assertEquals(0, d.mutations)
        server.shutdown()
    }

    @Test fun apiToolCallIsExecutedOnlyAfterApprovalAndResultIsReturned() = runBlocking {
        val server = MockWebServer(); server.start()
        server.enqueue(MockResponse().setBody("""{"choices":[{"message":{"tool_calls":[{"id":"call_click","type":"function","function":{"name":"click_text","arguments":"{\"text\":\"Open\",\"exact\":true}"}}]}}]}"""))
        server.enqueue(MockResponse().setBody("""{"choices":[{"message":{"tool_calls":[{"id":"call_finish","type":"function","function":{"name":"finish","arguments":"{\"summary\":\"opened\"}"}}]}}]}"""))
        val d = FakeDevice(); var approvals = 0
        val result = ActionRunner(ctx, d, settleMs = 0).run("open it", cfg.copy(baseUrl = server.url("/v1").toString()), {}) { approvals++; true }
        val first = JSONObject(server.takeRequest().body.readUtf8())
        val second = JSONObject(server.takeRequest().body.readUtf8())
        assertTrue(first.getJSONArray("tools").toString().contains("tap"))
        assertTrue(first.getJSONArray("tools").toString().contains("swipe"))
        assertEquals(1, approvals); assertEquals(1, d.mutations); assertTrue(result.contains("opened"))
        assertTrue(second.getJSONArray("messages").toString().contains("tool_call_id"))
        server.shutdown()
    }

    @Test fun actionControllerShowsAndCleansUp() {
        var stopped = false
        val controller = ActionPanel(ctx, { stopped = true }, {})
        controller.show()
        controller.status("Planning")
        controller.cancelApproval()
        controller.finish("Done")
        controller.remove()
        controller.remove() // idempotent on service destruction
        assertFalse(stopped)
    }
    @Test fun localModelMissingFailsWithoutNetworkFallback() = runBlocking {
        val config = LocalModels.config(ctx)
        try {
            LocalModels.generate(ctx, config, listOf(ChatMessage("user", "hello")))
            fail("No imported model")
        } catch (e: IllegalArgumentException) { assertTrue(e.message!!.contains("model", true)) }
    }
}
